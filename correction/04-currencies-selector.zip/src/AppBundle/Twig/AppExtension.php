<?php

namespace AppBundle\Twig;

use Symfony\Component\HttpFoundation\Session\SessionInterface;

class AppExtension extends \Twig_Extension
{

    private $currency;
    private $session;

    public function __construct(string $currency, SessionInterface $session)
    {
        $this->currency = $currency;
        $this->session = $session;
    }

    public function getFunctions():array
    {
        return [
            new \Twig_SimpleFunction('price_with_exchange_rate', [$this, 'priceWithExchangeRate']),
            new \Twig_SimpleFunction('get_currency_code', [$this, 'getCurrencyCode'])
        ];
    }

    public function priceWithExchangeRate(float $value):float
    {
        // si la clé existe en session, récupération du taux de change, sinon le taux est de 1
        $rate = $this->session->has('currency') ? $this->session->get('currency')['rate'] : 1;
        $result = $value * $rate;
        return $result;
    }

    public function getCurrencyCode()
    {
        // si la clé existe en session, récupération du code monnaie, sinon utilisation de la monnaie par défaut
        $result = $this->session->has('currency') ? $this->session->get('currency')['code'] : $this->currency;
        return $result;
    }

}