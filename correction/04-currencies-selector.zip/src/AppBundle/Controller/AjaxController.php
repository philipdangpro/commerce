<?php

namespace AppBundle\Controller;

use AppBundle\Entity\ExchangeRate;
use Doctrine\Common\Persistence\ManagerRegistry;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class AjaxController extends Controller
{
    /**
     * @Route("/ajax/currency-select", name="ajax.currency.select")
     */
    public function currencySelectAction(Request $request, ManagerRegistry $doctrine, SessionInterface $session):JsonResponse
    {
        // récupération de la variable POST envoyée par le JS
        $code = $request->request->get('code');

        // récupération du taux de change
        $result = $doctrine->getRepository(ExchangeRate::class)->findOneBy([
            'code' => $code
        ]);

        // stockage en session
        $session->set('currency', [
            'code' => $result->getCode(),
            'rate' => $result->getRate()
        ]);

        return new JsonResponse();
    }
}
