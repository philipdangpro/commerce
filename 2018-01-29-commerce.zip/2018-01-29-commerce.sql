-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: commerce
-- ------------------------------------------------------
-- Server version	5.7.21-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (33),(34),(35),(36),(37),(41),(42),(43);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_translation`
--

DROP TABLE IF EXISTS `category_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_translation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translatable_id` int(11) DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3F207045E237E06` (`name`),
  UNIQUE KEY `category_translation_unique_translation` (`translatable_id`,`locale`),
  KEY `IDX_3F207042C2AC5D3` (`translatable_id`),
  CONSTRAINT `FK_3F207042C2AC5D3` FOREIGN KEY (`translatable_id`) REFERENCES `category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_translation`
--

LOCK TABLES `category_translation` WRITE;
/*!40000 ALTER TABLE `category_translation` DISABLE KEYS */;
INSERT INTO `category_translation` VALUES (41,33,'category0','ALICE\'S RIGHT FOOT, ESQ. HEARTHRUG, NEAR THE FENDER, (WITH ALICE\'S LOVE). Oh dear, what nonsense I\'m talking!\' Just then she walked up towards it rather timidly, as she went on, \'\"--found it.','category0','en'),(42,33,'catégorie0','Cependant ces cadeaux l\'humiliaient. Il en est mort de quelqu\'un qui n\'a pas été trop bête! XIII À peine si quelques gouttes de rosée suspendues à la Vierge, il étendit les bras autour du poêle..','categorie0','fr'),(43,34,'category1','Alice to herself, \'it would have called him Tortoise because he taught us,\' said the Caterpillar. This was not a regular rule: you invented it just at present--at least I mean what I could let you.','category1','en'),(44,34,'catégorie1','Il portait ce jour-là la première ablation de maxillaire supérieur, n\'avaient certes le coeur plein des ustensiles et des queues lourdes. On ne peut être riche! Aucune fortune ne tient contre le.','categorie1','fr'),(45,35,'category2','NOT, being made entirely of cardboard.) \'All right, so far,\' thought Alice, as she could. \'The game\'s going on shrinking rapidly: she soon found herself at last it unfolded its arms, took the least.','category2','en'),(46,35,'catégorie2','Peut-être ne feriez-vous pas mal, lui dit Rodolphe. -- Nous en aurons d\'autres! reprit Emma. -- Eh bien, dit-il en se jetant dans les hôpitaux, on voyait un coin à quatre heures; les femmes, un rien.','categorie2','fr'),(47,36,'category3','Gryphon. \'Do you play croquet with the grin, which remained some time after the others. \'We must burn the house if it thought that it might happen any minute, \'and then,\' thought Alice, and she felt.','category3','en'),(48,36,'catégorie3','Emma prit sa main avec un bruit d\'étincelles. C\'était la première fois qu\'elle couchait dans la cuisine. Il guetta son ombre derrière la fenêtre, et le nouveau resta pendant deux heures et où.','categorie3','fr'),(49,37,'aa','zz','aa','en'),(50,37,'zzz','aaa','zzz','fr'),(56,41,'nomaen','descraen','nomaen','en'),(57,41,'nomanfr','descripfr','nomanfr','fr'),(58,42,'aadden','addescrip','aadden','en'),(59,42,'ajoutfrrr','descrifrrr','ajoutfrrr','fr'),(60,43,'ppp','pppp','ppp','en'),(61,43,'pp','pppppp','pp','fr');
/*!40000 ALTER TABLE `category_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `base` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rate` decimal(10,5) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_6956883FC0B4FE61` (`base`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (2,'EUR',1.00000,NULL),(3,'USD',1.24360,NULL),(4,'GBP',0.87335,NULL),(5,'TRY',3.33900,NULL);
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(5,2) NOT NULL,
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D34A04AD12469DE2` (`category_id`),
  CONSTRAINT `FK_D34A04AD12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (21,940.39,'img/product/0718fcf92e906f4be18a4bde672beba0.jpg/480/?37293',51,33),(22,798.74,'img/product/69a34fd4074b3e99500b4fed59de2adb.jpg/480/?12841',89,34),(23,751.92,'img/product/ef75923018ef3e4304efa52af2380f1c.jpg/480/?39694',85,35),(24,310.36,'img/product/9c66fded5abbcf128f311ec550b6af7c.jpg/480/?74595',19,36),(25,513.67,'img/product/e534d86e4bd158ccaa98560e9ef848f4.jpg/480/?22951',61,33),(26,447.14,'img/product/ef8363fb6620517017cb5e6cf8927f96.jpg/480/?22834',4,34),(27,557.11,'img/product/cce2998a737d1f24c9e7689e255d15e3.jpg/480/?23429',47,35),(28,112.45,NULL,1123,36),(29,214.14,'img/product/6509067950760e771cbdba034dcf966f.jpg/480/?50655',94,34),(30,900.16,'img/product/12c1a0c5d19f7740f17a715dfbed1596.jpg/480/?67582',84,35),(32,50.00,'/tmp/phpKfBHmK',50,35),(34,52.52,'/tmp/phpiE7S0d',5252,35),(35,66.00,'/tmp/phpmtvfrP',66,35),(36,66.00,'/tmp/phpGEAkyD',66,35),(37,55.00,'/tmp/phpGtZFOb',6655,35),(54,12.00,'img/product/PDA1516804920.jpg',12,35),(55,10.00,'img/product/PDA1516807534.jpg',10,35);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_translation`
--

DROP TABLE IF EXISTS `product_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_translation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translatable_id` int(11) DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_translation_unique_translation` (`translatable_id`,`locale`),
  KEY `IDX_1846DB702C2AC5D3` (`translatable_id`),
  CONSTRAINT `FK_1846DB702C2AC5D3` FOREIGN KEY (`translatable_id`) REFERENCES `product` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_translation`
--

LOCK TABLES `product_translation` WRITE;
/*!40000 ALTER TABLE `product_translation` DISABLE KEYS */;
INSERT INTO `product_translation` VALUES (41,21,'product0','VERY long claws and a pair of white kid gloves in one hand, and Alice was not even room for YOU, and no room to grow up again! Let me see--how IS it to the Queen, and Alice, were in custody and.','product0','en'),(42,21,'produit0','Mais il ne me repoussez pas! Vous êtes bonne! vous comprenez que je compte sur vous, n\'est-ce pas? non, je vous jure. «Mais messieurs, poursuivait le Conseiller, que si, écartant de mon idée, il.','produit0','fr'),(43,22,'product1','I know!\' exclaimed Alice, who was peeping anxiously into her eyes; and once again the tiny hands were clasped upon her face. \'Very,\' said Alice: \'--where\'s the Duchess?\' \'Hush! Hush!\' said the.','product1','en'),(44,22,'produit1','Mais, quand il y a trois semaines, j\'y étais!» Et peu à peu, ses gémissements furent plus forts. Un hurlement sourd lui échappa; elle prétendit qu\'elle allait abandonner? Mais elle demande à.','produit1','fr'),(45,23,'product2','But, now that I\'m doubtful about the games now.\' CHAPTER X. The Lobster Quadrille is!\' \'No, indeed,\' said Alice. \'I mean what I was a real Turtle.\' These words were followed by a very poor speaker,\'.','product2','en'),(46,23,'produit2','Celse, après quinze siècles d\'intervalle, la ligature immédiate d\'une artère; ni Dupuytren allant ouvrir un abcès à travers les carreaux, des gens de lettres et des manches de son amour; et elle se.','produit2','fr'),(47,24,'product3','Majesty,\' said Two, in a piteous tone. And she began fancying the sort of meaning in them, after all. \"--SAID I COULD NOT SWIM--\" you can\'t be civil, you\'d better ask HER about it.\' (The jury all.','product3','en'),(48,24,'produit3','Au bruit de la nuit, dans le Fanal de Rouen dans les bras dans l\'eau. Sur des perches partant du haut en bas, en espagnol et en recommençant trois fois, il fit dessiner dans son domaine! Et, en.','produit3','fr'),(49,25,'product4','AT ALL. Soup does very well to say it any longer than that,\' said the King, the Queen, tossing her head through the door, staring stupidly up into hers--she could hear the very tones of her voice..','product4','en'),(50,25,'produit4','Il lui semblait que le propriétaire n\'aimait point que l\'on croit voir, et il faisait depuis douze heures, il était difficile de comprendre ce qu\'elle s\'apprêtait de trop bonne heure. Elle ne se.','produit4','fr'),(51,26,'product5','I eat\" is the capital of Paris, and Paris is the reason so many lessons to learn! Oh, I shouldn\'t want YOURS: I don\'t understand. Where did they live at the Cat\'s head with great curiosity. \'Soles.','product5','en'),(52,26,'produit5','Emma; je souffre. -- Eh quoi! dit-il, ne savez-vous pas qu\'il y avait la tête de mort et la petite, M. Homais respectait les morts. Aussi, sans garder rancune au pauvre diable vagabondant avec son.','produit5','fr'),(53,27,'product6','PRECIOUS nose\'; as an explanation. \'Oh, you\'re sure to make herself useful, and looking anxiously about her. \'Oh, do let me hear the rattle of the baby, and not to be ashamed of yourself,\' said.','product6','en'),(54,27,'produit6','Rouault les fit reconduire dans sa limpidité. Quelquefois, à la figure, tandis qu\'à travers le bourdonnement de la seconde celle de son amant. On trouva même, au milieu des diligences. Un amas de.','produit6','fr'),(55,28,'product11','I\'111ll tell you how it was a sound of a procession,\' thought she, \'if people had all to lie down upon their faces. There was no time she\'d have everybody executed, all round. \'But she must have been a.','product11','en'),(56,28,'p11roduit7','Pui11s elle retomba dans son coin, où il s\'embarrassait, il aurait voulu ne rien voir, afin de lui mettre dans le coin, à gauche, ombragée par un coq gaulois, appuyé d\'une patte sur la fascination du.','p11roduit7','fr'),(57,29,'product8','I didn\'t know that you\'re mad?\' \'To begin with,\' the Mock Turtle: \'why, if a fish came to ME, and told me he was speaking, and this Alice thought to herself, (not in a deep voice, \'What are you.','product8','en'),(58,29,'produit8','Les chevaux soufflaient. Le cuir des selles craquait. Au moment où je vous assure, de véritables saintes, qui manquaient même de fort passant sur elle, qui la surprit elle-même. D\'ailleurs, elle se.','produit8','fr'),(59,30,'product9','Classics master, though. He was an immense length of neck, which seemed to be ashamed of yourself for asking such a curious appearance in the middle, wondering how she would manage it. \'They were.','product9','en'),(60,30,'produit9','C\'est alors qu\'Emma se repentit! Elle se demandait dans quel appartement se donnerait le dîner; on rêvait à la façon de s\'y trouver. Dès qu\'il entendait la sonnette, appela la servante de toutes ses.','produit9','fr'),(61,32,'productBB','descripBB','productbb','en'),(62,32,'produitBB','descriptiBB','produitbb','fr'),(65,34,'52enname','52endescription','52enname','en'),(66,34,'52frnom','52escripnt','52frnom','fr'),(67,35,'66name','66descri','66name','en'),(68,35,'66fr','66frdescr','66fr','fr'),(69,36,'66nddame','66dddescri','66nddame','en'),(70,36,'66fr','66frdescr','66fr','fr'),(71,37,'6zz6nddame','66dddescri','6zz6nddame','en'),(72,37,'66feer','66frdescr','66feer','fr'),(105,54,'oip','iopoip','oip','en'),(106,54,'iop','iopioui','iop','fr'),(107,55,'10','10','10','en'),(108,55,'10','10','10','fr');
/*!40000 ALTER TABLE `product_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'sdfsd','sdfsdfsdf','user@user.fr',1,NULL,NULL,NULL,NULL),(2,'sadfsd','fesdbxfcghjkl','aaaar@user.fr',1,NULL,NULL,NULL,NULL),(3,'fffff','$2y$13$qAWastSfEN3HbZcaWusMh.psFpIPF0bLEWPWr/hNdBv4drHbAKmlu','fff@gmail.com',1,NULL,NULL,NULL,NULL),(4,'gerard','$2y$13$U1eYmQdvGRCjS7yug9yQXuY06MiqRLQ21UjOcaP7/SVO9UzxqdJ/q','gerard@gmail.com',1,NULL,NULL,NULL,NULL),(5,'gsdferard','$2y$13$m8khSxr1UGXt1LeWXoIxweVJlCWdsbchasyUCF0V3SqJcvgwrFn.q','qszefsdgerard@gmail.com',1,NULL,NULL,NULL,NULL),(6,'philip','$2y$13$WmH8Rwe.ipkjdiSf4LQOJ.3Fn1Ktl3CB7IAWVRJghsz5tEttPqEWu','philip@gmail.com',1,NULL,NULL,NULL,NULL),(7,'hhhhh','$2y$13$Qj1zGL9xs59xvPn6O7X5vOse70IIwAu.Dl.M4h2uHhpjuALmS1y9.','hhh@gmail.com',1,NULL,NULL,NULL,NULL),(8,'hhheee','$2y$13$63GZc.0Q2.PuERApzRdYOus1c/zVrPgZYlXLbWW2Vv6F66C7PSZW6','heeehh@gmail.com',1,NULL,NULL,NULL,NULL),(9,'test','$2y$13$FXrAxaAmJUVa1FGNxsY5a.ZXpVG5.F7qgnMAuqeR6WeasfR6m0Btq','test@gmail.com',1,NULL,NULL,NULL,NULL),(10,'iiiii','$2y$13$bGlvZy6udX1vcAsdm93DOObzKFKToV7CYFPvTnvsWROTUqzcQsDNO','iiiii@gmail.com',1,NULL,NULL,NULL,NULL),(11,'tata','$2y$13$rhodlIOLH1xlVQyNB0rwxuVCKlLsWKJU9pFswmGD7FVbgeuKKS7cm','tata@gmail.com',1,NULL,NULL,NULL,NULL),(12,'tete','$2y$13$UXyzu2HYrijNFN9Uv74rZ.3.VAaW4/3QC5x3OGYHTq/hd6KTZWYvO','tete@gmail.com',1,NULL,NULL,NULL,NULL),(13,'tutu','$2y$13$0KhHTMMn9UUHZNMsN/Mmn.X25nFxJmzS7f0jiVfK0nCyFV81XgA..','tutu@gmail.com',1,NULL,NULL,NULL,NULL),(14,'tyty','$2y$13$Jq2RKJ1mdpvCtHBNvCttF.Upv/2K4IU95NpdGMjo6eHlOGQcNf3D.','tyty@gmail.com',1,NULL,NULL,NULL,NULL),(15,'baba','$2y$13$WcM9XzAN7DMrQ3QlIPJJqOVlkruTmShGhuPWziI3vbMk2HUDp5y8u','baba@gmail.com',1,NULL,NULL,NULL,NULL),(16,'bebe','$2y$13$Dd98pnRUCx784JQoLwW8zuOmRcdHx43iKn1TZ8n6PTZ0b0m.d7IBS','bebe@gmail.com',1,NULL,NULL,NULL,NULL),(17,'bobo','$2y$13$Pkk6tbOv30xIk72ZjA9B2.R4/O2s3yJIzPgye8q97yMbCuOUiIroq','bobo@gmail.com',1,NULL,NULL,NULL,NULL),(18,'bubu','$2y$13$to58Xnu5dF1AgFv4V8YDYukY7yrPFUtmeHe7NGdTNbpUJUE9//N.2','bubu@gmail.com',1,NULL,NULL,NULL,NULL),(19,'dadada','$2y$13$KBRoW2Bt8sXabkEZ1iiTqeCztwHdYdu4pxwG0menIjWF7jGvZ20AC','dadada@gmail.com',1,NULL,NULL,NULL,NULL),(20,'dadadaa','$2y$13$6Fgw/9.ip9cHtZ933U5KTu7FzGpjRT4MzbHdb/iNXqx3abK2uQegO','dadadaa@gmail.com',1,NULL,NULL,NULL,NULL),(47,'userEN1516283061','$2y$13$VHdxS8cbmVyG7DoDEsnsGe1HNLRfrDb.duDyFTEqW1cMrJy.xAhlu','user1516283061@user.com',1,NULL,NULL,NULL,NULL),(48,'userFR1516283119','$2y$13$na5rMaVyK9vmj/aTAez.serCTHM44MHL9st8YnHPmBnYKkcPnv2JS','user1516283119@user.com',1,NULL,NULL,NULL,NULL),(49,'userEN1516283122','$2y$13$Ihxeqsc0UswU0I.DrFuwEOg7JZJGnGBKQNoO7aIzkvbjcwBlbO4oW','user1516283122@user.com',1,NULL,NULL,NULL,NULL),(50,'userFR1516283397','$2y$13$aY9b.qzQDaByVUouUgjYc.BFpZT5eYFpMwAiFFwWGvdZJptu7iQby','user1516283397@user.com',1,NULL,NULL,NULL,NULL),(51,'userEN1516283401','$2y$13$qDWqbT2xZYQN7Sfn3HwZ6evaVSlb3ff0mznK/jYDAfrxDkm.UBuOe','user1516283401@user.com',1,NULL,NULL,NULL,NULL),(52,'userFR1516283408','$2y$13$V.X155xE..DIoD0xVKjAKOAUeACFM/9zBFPxcjEC1BKSNJVbiyRQe','user1516283408@user.com',1,NULL,NULL,NULL,NULL),(53,'userEN1516283412','$2y$13$YkHdkRlM97CzKnBnMC.ae.16.KoKS2xQb/evH/520/jxaGhVGgJzG','user1516283412@user.com',1,NULL,NULL,NULL,NULL),(54,'username','$2y$13$4AC1c/qHB3eIPRXREo.W5.T.JSFjNfNreIW1IkP3CEuGQplO0B0RG','username@gmail.com',1,NULL,NULL,NULL,NULL),(55,'mama','$2y$13$/1oDOqLOQXbB2A4p3MJbauy7CFGzLV7CfZA5M0Qe1qHai5KFmX8cm','mama@gmail.com',1,NULL,NULL,NULL,NULL),(56,'blabla','$2y$13$zcOusitz9rTiFXF5lLbpZ.O.W6CAD62QaidmZcBzx5UDXd0MtjiO.','blabla@gmail.com',1,NULL,NULL,NULL,NULL),(57,'blibli','$2y$13$liuc1kb9cD0f1HKDbvnc.eP7oIors8q9nF1OPZNTVNcxJgk38QV16','blibli@gmail.com',1,'s df sd fsgsd  gsdgsdf','45644','dfdf paris','AM');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_token`
--

DROP TABLE IF EXISTS `user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expiration_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_BDF55A63550872C` (`user_email`),
  UNIQUE KEY `UNIQ_BDF55A635F37A13B` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_token`
--

LOCK TABLES `user_token` WRITE;
/*!40000 ALTER TABLE `user_token` DISABLE KEYS */;
INSERT INTO `user_token` VALUES (6,'bobo@gmail.com','8eaf579a97dcf45b5ca3','2019-01-20 16:18:08'),(8,'baba@gmail.com','31471c284888bd54300e','2019-01-20 16:38:53'),(15,'mama@gmail.com','d2e05ba8821cb5df0c40','2019-01-23 10:32:49');
/*!40000 ALTER TABLE `user_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-29 16:42:29
