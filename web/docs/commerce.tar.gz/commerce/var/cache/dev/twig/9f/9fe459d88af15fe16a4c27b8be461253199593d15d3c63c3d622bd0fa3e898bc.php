<?php

/* homepage/index.html.twig */
class __TwigTemplate_2773ea8f66d4446f145892d80b5fa0ad520f9be8035dfb351ec6a0356ad04110 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "homepage/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e32a2c7b34d35791225f304fae5a1a9b5fe879bfca2200ed3dd300f9de96e90e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e32a2c7b34d35791225f304fae5a1a9b5fe879bfca2200ed3dd300f9de96e90e->enter($__internal_e32a2c7b34d35791225f304fae5a1a9b5fe879bfca2200ed3dd300f9de96e90e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "homepage/index.html.twig"));

        $__internal_df4327430bc5c7b8be864b1233f669e01dac503d42fe342e80deed4612f8a390 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df4327430bc5c7b8be864b1233f669e01dac503d42fe342e80deed4612f8a390->enter($__internal_df4327430bc5c7b8be864b1233f669e01dac503d42fe342e80deed4612f8a390_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "homepage/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e32a2c7b34d35791225f304fae5a1a9b5fe879bfca2200ed3dd300f9de96e90e->leave($__internal_e32a2c7b34d35791225f304fae5a1a9b5fe879bfca2200ed3dd300f9de96e90e_prof);

        
        $__internal_df4327430bc5c7b8be864b1233f669e01dac503d42fe342e80deed4612f8a390->leave($__internal_df4327430bc5c7b8be864b1233f669e01dac503d42fe342e80deed4612f8a390_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_7824ee5f5386d8bb648ce52fd092069cc6582e2c8450fb459e87d60100c381c6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7824ee5f5386d8bb648ce52fd092069cc6582e2c8450fb459e87d60100c381c6->enter($__internal_7824ee5f5386d8bb648ce52fd092069cc6582e2c8450fb459e87d60100c381c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d811fe3d633116c6c08b3a30e3b0e07994c90dcfcb7886355fc8f7ed74a88548 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d811fe3d633116c6c08b3a30e3b0e07994c90dcfcb7886355fc8f7ed74a88548->enter($__internal_d811fe3d633116c6c08b3a30e3b0e07994c90dcfcb7886355fc8f7ed74a88548_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"row\">
        <div class=\"col\">
            <h1>Accueil</h1>
        </div>
    </div>
";
        
        $__internal_d811fe3d633116c6c08b3a30e3b0e07994c90dcfcb7886355fc8f7ed74a88548->leave($__internal_d811fe3d633116c6c08b3a30e3b0e07994c90dcfcb7886355fc8f7ed74a88548_prof);

        
        $__internal_7824ee5f5386d8bb648ce52fd092069cc6582e2c8450fb459e87d60100c381c6->leave($__internal_7824ee5f5386d8bb648ce52fd092069cc6582e2c8450fb459e87d60100c381c6_prof);

    }

    public function getTemplateName()
    {
        return "homepage/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"row\">
        <div class=\"col\">
            <h1>Accueil</h1>
        </div>
    </div>
{% endblock %}
", "homepage/index.html.twig", "/home/wabap2-1/Bureau/commerce/app/Resources/views/homepage/index.html.twig");
    }
}
