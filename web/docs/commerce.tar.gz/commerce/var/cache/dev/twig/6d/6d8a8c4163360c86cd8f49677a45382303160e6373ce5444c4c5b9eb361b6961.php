<?php

/* base.html.twig */
class __TwigTemplate_ef6a598e82a5011af52d5b328f0cd2f8830bea5f4c88506ad9e23671aec9697a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fcdefda5d9792d7fd59b52bd497cfbb4ba02b7f78eb545742aeda2c66008f53b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fcdefda5d9792d7fd59b52bd497cfbb4ba02b7f78eb545742aeda2c66008f53b->enter($__internal_fcdefda5d9792d7fd59b52bd497cfbb4ba02b7f78eb545742aeda2c66008f53b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_ce8f6838fba69736c6b288341036dc446c96bd10c8c2a6c818f67b15acf3181b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce8f6838fba69736c6b288341036dc446c96bd10c8c2a6c818f67b15acf3181b->enter($__internal_ce8f6838fba69736c6b288341036dc446c96bd10c8c2a6c818f67b15acf3181b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/reset.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/fontawesome-all.min.css"), "html", null, true);
        echo "\">
        ";
        // line 9
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "    </head>
    <body>

        <div class=\"container\">
            ";
        // line 14
        $this->displayBlock('body', $context, $blocks);
        // line 15
        echo "        </div>

        <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-3.2.1.slim.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/popper.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 20
        $this->displayBlock('javascripts', $context, $blocks);
        // line 21
        echo "    </body>
</html>
";
        
        $__internal_fcdefda5d9792d7fd59b52bd497cfbb4ba02b7f78eb545742aeda2c66008f53b->leave($__internal_fcdefda5d9792d7fd59b52bd497cfbb4ba02b7f78eb545742aeda2c66008f53b_prof);

        
        $__internal_ce8f6838fba69736c6b288341036dc446c96bd10c8c2a6c818f67b15acf3181b->leave($__internal_ce8f6838fba69736c6b288341036dc446c96bd10c8c2a6c818f67b15acf3181b_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_7c9eb41d120b5715ce719b1419d206b8720829091ccb5ba37eab7a19e65be11f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7c9eb41d120b5715ce719b1419d206b8720829091ccb5ba37eab7a19e65be11f->enter($__internal_7c9eb41d120b5715ce719b1419d206b8720829091ccb5ba37eab7a19e65be11f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_49c8b90ad216f8326e287359210f2bdb9ce8f7a5ee8ee6da4c4306fd3b955073 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49c8b90ad216f8326e287359210f2bdb9ce8f7a5ee8ee6da4c4306fd3b955073->enter($__internal_49c8b90ad216f8326e287359210f2bdb9ce8f7a5ee8ee6da4c4306fd3b955073_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Commerce";
        
        $__internal_49c8b90ad216f8326e287359210f2bdb9ce8f7a5ee8ee6da4c4306fd3b955073->leave($__internal_49c8b90ad216f8326e287359210f2bdb9ce8f7a5ee8ee6da4c4306fd3b955073_prof);

        
        $__internal_7c9eb41d120b5715ce719b1419d206b8720829091ccb5ba37eab7a19e65be11f->leave($__internal_7c9eb41d120b5715ce719b1419d206b8720829091ccb5ba37eab7a19e65be11f_prof);

    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_799caa8c59cf1f3e1c692f50094b3430f5ebe5e9f26ad5fc4d8c3615914c86ce = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_799caa8c59cf1f3e1c692f50094b3430f5ebe5e9f26ad5fc4d8c3615914c86ce->enter($__internal_799caa8c59cf1f3e1c692f50094b3430f5ebe5e9f26ad5fc4d8c3615914c86ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_2c2c8edba8d6ba9688ab8abd6eb77e72e76266688cc17371bab27eac1796a9d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c2c8edba8d6ba9688ab8abd6eb77e72e76266688cc17371bab27eac1796a9d3->enter($__internal_2c2c8edba8d6ba9688ab8abd6eb77e72e76266688cc17371bab27eac1796a9d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_2c2c8edba8d6ba9688ab8abd6eb77e72e76266688cc17371bab27eac1796a9d3->leave($__internal_2c2c8edba8d6ba9688ab8abd6eb77e72e76266688cc17371bab27eac1796a9d3_prof);

        
        $__internal_799caa8c59cf1f3e1c692f50094b3430f5ebe5e9f26ad5fc4d8c3615914c86ce->leave($__internal_799caa8c59cf1f3e1c692f50094b3430f5ebe5e9f26ad5fc4d8c3615914c86ce_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_35ceb924567551bf965e1d738b17381544125f0f30b51207ca9bb8cf04062f2b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35ceb924567551bf965e1d738b17381544125f0f30b51207ca9bb8cf04062f2b->enter($__internal_35ceb924567551bf965e1d738b17381544125f0f30b51207ca9bb8cf04062f2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5e2600c8fe9de395d9b926a4a039f2fb3d4a723f280f415734e7b032ab2f97b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e2600c8fe9de395d9b926a4a039f2fb3d4a723f280f415734e7b032ab2f97b6->enter($__internal_5e2600c8fe9de395d9b926a4a039f2fb3d4a723f280f415734e7b032ab2f97b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_5e2600c8fe9de395d9b926a4a039f2fb3d4a723f280f415734e7b032ab2f97b6->leave($__internal_5e2600c8fe9de395d9b926a4a039f2fb3d4a723f280f415734e7b032ab2f97b6_prof);

        
        $__internal_35ceb924567551bf965e1d738b17381544125f0f30b51207ca9bb8cf04062f2b->leave($__internal_35ceb924567551bf965e1d738b17381544125f0f30b51207ca9bb8cf04062f2b_prof);

    }

    // line 20
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_729f4c6803cb0e8ec6293df582d4acf7da48f6dbbbbb83669c5dd668e41ce73a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_729f4c6803cb0e8ec6293df582d4acf7da48f6dbbbbb83669c5dd668e41ce73a->enter($__internal_729f4c6803cb0e8ec6293df582d4acf7da48f6dbbbbb83669c5dd668e41ce73a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_36852df255e4906f8f1503957bf6bfa61f4ee61833d784094213c971a5e0b605 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36852df255e4906f8f1503957bf6bfa61f4ee61833d784094213c971a5e0b605->enter($__internal_36852df255e4906f8f1503957bf6bfa61f4ee61833d784094213c971a5e0b605_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_36852df255e4906f8f1503957bf6bfa61f4ee61833d784094213c971a5e0b605->leave($__internal_36852df255e4906f8f1503957bf6bfa61f4ee61833d784094213c971a5e0b605_prof);

        
        $__internal_729f4c6803cb0e8ec6293df582d4acf7da48f6dbbbbb83669c5dd668e41ce73a->leave($__internal_729f4c6803cb0e8ec6293df582d4acf7da48f6dbbbbb83669c5dd668e41ce73a_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 20,  126 => 14,  109 => 9,  91 => 5,  79 => 21,  77 => 20,  73 => 19,  69 => 18,  65 => 17,  61 => 15,  59 => 14,  53 => 10,  51 => 9,  47 => 8,  43 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Commerce{% endblock %}</title>
        <link rel=\"stylesheet\" href=\"{{ asset('css/reset.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/fontawesome-all.min.css') }}\">
        {% block stylesheets %}{% endblock %}
    </head>
    <body>

        <div class=\"container\">
            {% block body %}{% endblock %}
        </div>

        <script src=\"{{ asset('js/jquery-3.2.1.slim.min.js') }}\"></script>
        <script src=\"{{ asset('js/popper.min.js') }}\"></script>
        <script src=\"{{ asset('js/bootstrap.min.js') }}\"></script>
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/home/wabap2-1/Bureau/commerce/app/Resources/views/base.html.twig");
    }
}
