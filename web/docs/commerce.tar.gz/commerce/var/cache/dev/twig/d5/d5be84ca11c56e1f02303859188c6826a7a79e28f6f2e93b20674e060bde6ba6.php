<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_4e3271903e33ece75271e854a17246dc43a169ac90a69a863843468c5ada6dd1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_508dfb78987bd88730f5752d37852b3eb21b1dbe9550f5e72f23a45f05a52a3d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_508dfb78987bd88730f5752d37852b3eb21b1dbe9550f5e72f23a45f05a52a3d->enter($__internal_508dfb78987bd88730f5752d37852b3eb21b1dbe9550f5e72f23a45f05a52a3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_116bb3d5c597e367be607fd3065bf4ae8a65895a12cfc96af9a01ca006873a49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_116bb3d5c597e367be607fd3065bf4ae8a65895a12cfc96af9a01ca006873a49->enter($__internal_116bb3d5c597e367be607fd3065bf4ae8a65895a12cfc96af9a01ca006873a49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_508dfb78987bd88730f5752d37852b3eb21b1dbe9550f5e72f23a45f05a52a3d->leave($__internal_508dfb78987bd88730f5752d37852b3eb21b1dbe9550f5e72f23a45f05a52a3d_prof);

        
        $__internal_116bb3d5c597e367be607fd3065bf4ae8a65895a12cfc96af9a01ca006873a49->leave($__internal_116bb3d5c597e367be607fd3065bf4ae8a65895a12cfc96af9a01ca006873a49_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_1dcad5d20de175b014fa2b93d9e1988bfcb248fbd8d8e3870e72242552046846 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1dcad5d20de175b014fa2b93d9e1988bfcb248fbd8d8e3870e72242552046846->enter($__internal_1dcad5d20de175b014fa2b93d9e1988bfcb248fbd8d8e3870e72242552046846_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_cb338be23d2060f6684eaf138af3ccfc0995e72fc9cd8158a4e5854e379c5afd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb338be23d2060f6684eaf138af3ccfc0995e72fc9cd8158a4e5854e379c5afd->enter($__internal_cb338be23d2060f6684eaf138af3ccfc0995e72fc9cd8158a4e5854e379c5afd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_cb338be23d2060f6684eaf138af3ccfc0995e72fc9cd8158a4e5854e379c5afd->leave($__internal_cb338be23d2060f6684eaf138af3ccfc0995e72fc9cd8158a4e5854e379c5afd_prof);

        
        $__internal_1dcad5d20de175b014fa2b93d9e1988bfcb248fbd8d8e3870e72242552046846->leave($__internal_1dcad5d20de175b014fa2b93d9e1988bfcb248fbd8d8e3870e72242552046846_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_c37fb1f786f174e4b377ace6bc20b474b057fee9302e1b12a12841214abb4174 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c37fb1f786f174e4b377ace6bc20b474b057fee9302e1b12a12841214abb4174->enter($__internal_c37fb1f786f174e4b377ace6bc20b474b057fee9302e1b12a12841214abb4174_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_68992d10b7f2bec6a30849e375d86d9502b37c167fc1284e05e09b2bf9a5fa89 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68992d10b7f2bec6a30849e375d86d9502b37c167fc1284e05e09b2bf9a5fa89->enter($__internal_68992d10b7f2bec6a30849e375d86d9502b37c167fc1284e05e09b2bf9a5fa89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_68992d10b7f2bec6a30849e375d86d9502b37c167fc1284e05e09b2bf9a5fa89->leave($__internal_68992d10b7f2bec6a30849e375d86d9502b37c167fc1284e05e09b2bf9a5fa89_prof);

        
        $__internal_c37fb1f786f174e4b377ace6bc20b474b057fee9302e1b12a12841214abb4174->leave($__internal_c37fb1f786f174e4b377ace6bc20b474b057fee9302e1b12a12841214abb4174_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_338557240aa81275d16654de6078de9120bbfc06c8622ec8f59cb7b4a9be9833 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_338557240aa81275d16654de6078de9120bbfc06c8622ec8f59cb7b4a9be9833->enter($__internal_338557240aa81275d16654de6078de9120bbfc06c8622ec8f59cb7b4a9be9833_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_79dc1c4a6676d4fbeb25df82fd7be217f5e763bb39c6c0fb97cf8edfdf8635e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79dc1c4a6676d4fbeb25df82fd7be217f5e763bb39c6c0fb97cf8edfdf8635e2->enter($__internal_79dc1c4a6676d4fbeb25df82fd7be217f5e763bb39c6c0fb97cf8edfdf8635e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_79dc1c4a6676d4fbeb25df82fd7be217f5e763bb39c6c0fb97cf8edfdf8635e2->leave($__internal_79dc1c4a6676d4fbeb25df82fd7be217f5e763bb39c6c0fb97cf8edfdf8635e2_prof);

        
        $__internal_338557240aa81275d16654de6078de9120bbfc06c8622ec8f59cb7b4a9be9833->leave($__internal_338557240aa81275d16654de6078de9120bbfc06c8622ec8f59cb7b4a9be9833_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/home/wabap2-1/Bureau/commerce/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
