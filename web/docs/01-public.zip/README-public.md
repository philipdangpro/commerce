# Intitulé

Création de la partie publique d'un site vitrine

# Description

La première page

* est la page d'accueil

* liste les catégories

* le nombre de produits présents dans chaque catégorie est affiché dans un lien

* la zone de suggestion affichent trois produits aléatoires

La deuxième page

* liste les produits présents dans chaque catégorie

La troisième page

* affiche les détails d'un produit

# Informations techniques

La route de la première page doit être de la forme "/"

La route de la deuxième page doit être de la forme "/c/SLUG-DE-LA-CATEGORIE"

La route de la troisième page doit être de la forme "/p/SLUG-DE-LA-CATEGORIE/SLUG-DU-PRODUIT"

# Fichiers fournis

La mise en page des vues réalisée à l'aide de Bootstrap